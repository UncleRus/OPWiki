#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qextserialport.h"
#include "qextserialenumerator.h"
bool sortPorts(const QextPortInfo &s1,const QextPortInfo &s2)
{
    return s1.portName<s2.portName;
}
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QextSerialEnumerator enumerator;
    QList<QextPortInfo> ports = QextSerialEnumerator::getPorts();

    //sort the list by port number (nice idea from PT_Dreamer :))
    qSort(ports.begin(), ports.end(),sortPorts);
    foreach( QextPortInfo port, ports ) {
#ifdef Q_OS_WIN
            ui->cb_ports->addItem(port.friendName,port.portName);
#else
            ui->cb_ports->addItem(port.friendName,port.physName);
#endif
    }
    port=new QextSerialPort(QextSerialPort::Polling);
    set.BaudRate = BAUD9600;
    set.DataBits = DATA_8;
    set.Parity = PAR_NONE;
    set.StopBits = STOP_1;
    set.FlowControl = FLOW_OFF;
    set.Timeout_Millisec = 500;
    port=new QextSerialPort(set,QextSerialPort::Polling);
    ui->cb_speedcon->setCurrentIndex(ui->cb_speedcon->findText("9600"));
}



MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_bt_find_clicked()
{

    for(int x=0;x<ui->cb_ports->count();++x)
    {
        ui->output->append("Trying to open "+ui->cb_ports->itemText(x));
        port->setPortName(ui->cb_ports->itemData(x).toString());
        if(port->open(QIODevice::ReadWrite))
        {
            ui->output->append("success");
            for(int y=0;y<ui->cb_speedcon->count();++y)
            {
                set.BaudRate=stringToBaud(ui->cb_speedcon->itemText(y));
                port->close();
                port->setBaudRate(set.BaudRate);
                port->open(QIODevice::ReadWrite);
                ui->output->append("Trying to talk with module at "+ui->cb_speedcon->itemText(y)+ "bps");
                port->write("AT");
                QApplication::processEvents();
                QByteArray ans=port->read(2);
                ui->output->append("sent AT received " + ans);
                if(ans=="OK")
                {
                    ui->output->append("Bluetooth module found at port "+ui->cb_ports->itemText(x)+" at "+ui->cb_speedcon->itemText(y)+ "bps");
                    ui->cb_ports->setCurrentIndex(x);
                    ui->cb_speedcon->setCurrentIndex(y);
                    return;
                }
            }
            port->close();
        }
        else
            ui->output->append("failed");

    }
}

BaudRateType MainWindow::stringToBaud(QString str)
{
    if(str=="1200")
        return BAUD1200;
    else if(str=="2400")
        return BAUD1200;
    else if(str== "4800")
        return BAUD2400;
    else if(str== "9600")
        return BAUD9600;
    else if(str== "19200")
        return BAUD19200;
    else if(str== "38400")
        return BAUD38400;
    else if(str== "57600")
        return BAUD56000;
    else if(str== "115200")
        return BAUD115200;
    else if(str== "230400")
        return BAUD230400;
    else if(str== "460800")
        return BAUD460800;
    else if(str== "921600")
        return BAUD921600;
}

void MainWindow::on_bt_connect_clicked()
{
    if(port->isOpen())
        port->close();
    if(ui->bt_connect->text()=="disconnect")
    {
        ui->bt_write->setEnabled(false);
        ui->bt_connect->setText("connect");
        ui->bt_find->setEnabled(true);
        return;
    }
    set.BaudRate=stringToBaud(ui->cb_speedcon->currentText());
    port->setBaudRate(set.BaudRate);
    port->setPortName(ui->cb_ports->itemData(ui->cb_ports->currentIndex()).toString());
    if(port->open(QIODevice::ReadWrite))
    {
         ui->output->append("Port opening success");
         ui->output->append("Checking if module is present");
         port->write("AT");
         QApplication::processEvents();
         QByteArray ans=port->read(2);
         ui->output->append("sent AT received " + ans);
         if(ans=="OK")
         {
             ui->output->append("Module found!");
             ui->output->append("Retrieving firmware version");
             QApplication::processEvents();
             port->write("AT+VERSION");
             QByteArray ans=port->read(20);
             ui->output->append("sent AT+VERSION received " + ans);
             ui->lb_version->setText(ans.mid(2,-1));
             ui->bt_write->setEnabled(true);
             ui->bt_connect->setText("disconnect");
             ui->bt_find->setEnabled(false);
         }
         else
             ui->output->append("Module not found!");
    }
    else
        ui->output->append("Port opening failed");
}

void MainWindow::on_bt_write_clicked()
{
    QApplication::processEvents();
    port->write("AT+BAUD"+QString::number(ui->comboBox->currentIndex()+1).toAscii());
    QByteArray ans=port->read(20);
    ui->output->append("sent AT+BAUD"+QString::number(ui->comboBox->currentIndex()+1)+" received " + ans);
    if(ans=="OK"+ui->comboBox->currentText())
        ui->output->append("speed setting succeeded");
    else
        ui->output->append("speed setting failed");

    set.BaudRate=stringToBaud(ui->comboBox->currentText());
    port->close();
    port->setBaudRate(set.BaudRate);
    port->open(QIODevice::ReadWrite);

    QApplication::processEvents();
    port->write("AT+NAME"+ui->lb_name->text().toAscii());
    ans=port->read(20);
    ui->output->append("sent AT+NAME"+ui->lb_name->text()+" received " + ans);
    if(ans=="OKsetname")
        ui->output->append("name setting succeeded");
    else
        ui->output->append("name setting failed");

    QApplication::processEvents();
    port->write("AT+PIN"+ui->lb_pin->text().toAscii());
    ans=port->read(20);
    ui->output->append("sent AT+PIN"+ui->lb_pin->text()+" received " + ans);
    if(ans=="OKsetPIN")
        ui->output->append("PIN setting succeeded");
    else
        ui->output->append("PIN setting failed");

}
